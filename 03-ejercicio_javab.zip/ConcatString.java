package com.openbootcamp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Author: Diabolik
 * Ejercicio 2 Open BootCamp Java Básico
 * Crear un bucle que permita concatenar textos e imprima el resultado final por consola.
 */

public class ConcatString {

    public static void main(String[] args) {

        List<String> myText = new ArrayList<>();

        System.out.println("For Exit press enter 'P' ");

        // El usuario escribe un texto y se agrega a la lista de Strings
        addName(myText);

        // Imprime todos los nombres separados, pase false para eliminar el espacio
        printNames(myText);

        System.out.println("\n ¡Adios!");
    }

    public static void addName(List<String> names){
        Scanner input = new Scanner(System.in);
        String newText = "";
        while(!newText.equalsIgnoreCase("P")){
            System.out.print("Insert a name: ");
            newText = input.nextLine();
            if(!newText.equalsIgnoreCase("P"))
                names.add(newText);
        }
    }

    public static void printNames(List<String> names, boolean separated){
        boolean separate = true;
        System.out.println("Resultado:");
        for(String i : names){
            System.out.print(i);
            if(separated)
                System.out.print(" ");
        }
    }

    public static void printNames(List<String> names){
        printNames(names, true);
    }

}
