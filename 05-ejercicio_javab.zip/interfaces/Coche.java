package com.openbootcamp.interfaces;

public class Coche {

    String fabricante;
    String modelo;
    double cc;
    boolean sport;

    public Coche() {
    }

    public Coche(String fabricante, String modelo, double cc, boolean sport) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.cc = cc;
        this.sport = sport;
    }

    @Override
    public String toString() {
        return "Coche{" +
                "fabricante='" + fabricante + '\'' +
                ", modelo='" + modelo + '\'' +
                ", cc=" + cc +
                ", sport=" + sport +
                '}';
    }
}
