package com.openbootcamp.interfaces;

public interface CocheCRUD {

    void save(Coche coche);
    void findAll();
    void delete(Coche coche);
    void clean();

}
