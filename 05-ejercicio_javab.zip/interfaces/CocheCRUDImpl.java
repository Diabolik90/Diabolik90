package com.openbootcamp.interfaces;

import com.sun.tools.jconsole.JConsoleContext;

import java.util.ArrayList;
import java.util.List;

public class CocheCRUDImpl implements CocheCRUD{

    private List<Coche> coches = new ArrayList<>();

    @Override
    public void save(Coche coche) {
        coches.add(coche);
    }

    @Override
    public void findAll() {
        System.out.println(coches);
    }

    @Override
    public void delete(Coche coche) {
        coches.remove(coche);
    }

    @Override
    public void clean() {
        coches.clear();
    }


}
