package com.openbootcamp.interfaces;

/**
 * Author: Diabolik
 * Ejercicio 5 Open BootCamp Java Básico
 *
 * Crear una implementación CocheCRUDImpl que implemente la interfaz CocheCRUD.
 *
 * Como métodos de CocheCRUD podemos poner:
 * save()
 * findAll()
 * delete()
 * que simplemente impriman por consola el nombre del propio método.
 *
 * Desde una clase Main, Crear un objeto de tipo CocheCRUDImpl y llamar a cada uno de los métodos.
 *
 * Ejemplo: CocheCRUD cocheCrud = new CocheCRUDImpl()
 */

public class Main {

    public static void main(String[] args) {

        CocheCRUD cocheCrud = new CocheCRUDImpl();

        Coche focus = new Coche("Ford","Focus",2.6,true);

        System.out.println("Añadir todos los coches");

        // save
        cocheCrud.save(focus);
        cocheCrud.save(new Coche("Citroen","Scenic",1.8,false));
        cocheCrud.save(new Coche("Fiat","Panda",1.2,false));
        cocheCrud.save(new Coche("Seat","Ibiza",1.8,true));

        // findAll
        cocheCrud.findAll();

        System.out.println("Test borrar coche Ford Focus");

        // delete
        cocheCrud.delete(focus);

        cocheCrud.findAll();

        System.out.println("Test limpieza de la lista");

        // clean
        cocheCrud.clean();

        cocheCrud.findAll();

        System.out.println("¡Adios!");
    }
}
