package com.openbootcamp;

/**
 * Crea un proyecto de Java desde 0
 * Dentro del proyecto tenéis que crear un paquete. En el paquete tendréis que crear una clase.
 * Dentro de la clase tenéis que crear el método main e imprimir todos los datos que se han visto en las sesiones.
 */

public class Main {

    public static void main(String[] args) {

        byte primero = 1;   // 1 byte
        short segundo = 2;  // 2 byte
        int tercero = 3;    // 4 byte
        float cuarto = 4.1f;    // 4 byte
        long quinto = 5L;    // 8 byte
        double sexto = 6.2d;    // 8 byte

        boolean verdadero = true;
        char character = 'a';
        String nombre = "Diabolik";
        Integer number = null;
        Long longNum = 2L;

        System.out.println("byte: " + primero);
        System.out.println("short: " + segundo);
        System.out.println("int: " + tercero);
        System.out.println("float: " + cuarto);
        System.out.println("long: " + quinto);
        System.out.println("double: " + sexto);
        System.out.println("boolean: " + verdadero);
        System.out.println("char: " + character);
        System.out.println("String: " + nombre);
        System.out.println("Integer: " + number);
        System.out.println("Long: " + longNum);

    }
}
