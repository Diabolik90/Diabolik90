package universalCode;

import program.DBKManager;

import java.io.*;
import java.util.Arrays;
import java.util.Random;

public class Code {

    private static final int kChar = 90;
    private static final int kMin = 33;
    private int id;
    private char[] c = new char[kChar];

    public Code() {
        id = lastId();
    }

    public Code(char[] c) {
        this.c = c;
        id = lastId();
    }

    public Code(int id){
        if(!read(id)){
            System.out.println("Error [Code 26]: en leer el id de CODE.");
        }
    }

    /**
     * Crear una combinación aleatoria,
     * comprobar si no existe ya y la guardar en el archivo
     */
    public void create(){
        Random rand = new Random();
        boolean control = false;
        do{
            for(int i = 0; i < kChar; i++){
                c[i] = (char)(rand.nextInt(kChar) + kMin);
                if(c[i] == 44){
                    c[i] = 126;
                }
                for(int j = 0; j < i; j++){
                    if(c[i] == c[j]){
                        i--;
                        j = i;
                    }
                }
            }
            control = verificated(c);
        }while(!control);

        save(c);
    }

    /**
     * Comproba si el archivo está vacío
     */
    public static boolean isEmpty(){
        int counter = 0;
        boolean empty = true;
        try{
            InputStream f = new FileInputStream(DBKManager.getFicheroCode());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            int datos = bFichero.read();
            while (datos != -1 && counter == 0){
                counter++;
                datos = bFichero.read();
            }
            bFichero.close();
            f.close();
        }catch (IOException e){
            empty = true;
        }
        if(counter > 0)
            empty = false;
        return empty;
    }

    /**
     * Comprueba el último id guardado y devuelve el siguiente.
     * Si el archivo está vacío retorna 0
     */
    public static int lastId(){
        if(isEmpty()){
            return 0;
        }
        String id = "";
        int result = 0;
        boolean start = false;
        boolean copy = false;
        try{
            InputStream f = new FileInputStream(DBKManager.getFicheroCode());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            int datos = bFichero.read();
            while (datos != -1){
                if(copy){
                    // solo numeros
                    if(48 <= (char)datos && 57 >= (char)datos){
                        id += (char)datos;
                    }else{
                        try{
                            result = Integer.parseInt(id);
                        }catch (Exception e){
                            System.out.println("Error [Code 105]: id=[" + id + "] no es un numero.");
                        }
                        id = "";
                        copy = false;
                    }
                }else{
                    // busco |
                    if(124 != (char)datos){
                        id += (char)datos;
                    }else if(id.contains("DBKCode{id")){
                        copy = true;
                        id = "";
                    }
                }
                datos = bFichero.read();
            }
            bFichero.close();
            f.close();
        }catch (IOException e){
            System.out.println("Error [Code 124]: al leer el último id.");
        }
        result += 1;
        return result;
    }

    /**
     * A través del id carga la codificación
     */
    public boolean read(final int id){
        if(isEmpty()){
            System.out.println("Error [Code 135]: imposible leer. Falta el fichero.");
            return false;
        }
        boolean found = false;
        try{
            InputStream f = new FileInputStream(DBKManager.getFicheroCode());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            String tmpID = "";
            int result = 0;
            int i = 0;
            boolean copy = false;
            boolean block = true;
            boolean complete = false;
            int datos = bFichero.read();
            while (datos != -1 && !complete){
                if(found){
                    if(block){
                        tmpID += (char)datos;
                        if(tmpID.equals("c|[")){
                            block = false;
                        }
                    }else{
                        if((char)datos != 32 && (char)datos != 44){
                            try{
                                this.c[i] = (char)datos;
                                i++;
                            }catch (Exception e){
                                System.out.println("Error [Code 162]: el valor del index " + i + " es superior al limite " + kChar);
                            }
                            if(i >= kChar)
                                complete = true;
                        }
                    }
                }else {
                    if(copy){
                        // solo numeros
                        if(48 <= (char)datos && 57 >= (char)datos){
                            tmpID += (char)datos;
                        }else{
                            try{
                                result = Integer.parseInt(tmpID);
                                if(result == id){
                                    this.id = id;
                                    found = true;
                                }
                            }catch (Exception e){
                                System.out.println("Error [Code 181]: id=[" + id + "] no es un numero.");
                            }
                            tmpID = "";
                            copy = false;
                        }
                    }else{
                        // busco |
                        if(124 != (char)datos){
                            tmpID += (char)datos;
                        }else if(tmpID.contains("DBKCode{id")){
                            copy = true;
                            tmpID = "";
                        }
                    }
                }

                datos = bFichero.read();
            }
            bFichero.close();
            f.close();
        }catch (IOException e){
            System.out.println("Error [Code 202]: al leer el último id.");
        }
        return found;
    }

    /**
     * Codifica el texto en función de su cadena de codificación
     */
    public String codification(String pwd){
        if(isEmpty()){
            System.out.println("Error [Code 212]: imposible codificar. Falta el fichero.");
            return "";
        }
        String result = "";
        int pos;
        char myC;
        for(int i = 0; i < pwd.length(); i++){
            if(32 == pwd.charAt(i)){
                System.out.println("El \"espacio\" no se puede codificar");
            }else{
                myC = pwd.charAt(i);
                pos = myC - kMin;
                if(pos < kChar){
                    result += this.c[pos];
                }else{
                    System.out.println("Error [Code 227]: valore di pos troppo elevato " + pos + ". lavoro su " + pwd.charAt(i));
                }
            }
        }
        return result;
    }

    /**
     * Decodifica el texto en función de su cadena de codificación
     */
    public String decodification(String pwd){
        if(isEmpty()){
            System.out.println("Error [Code 239]: imposible decodificar. Falta el fichero.");
            return "";
        }
        String result = "";
        char tmpC;
        for(int i = 0; i < pwd.length(); i++){
            if(pwd.charAt(i) == 44){
                result += pwd.charAt(i);
            }else{
                for(int j = 0; j < kChar; j++){
                    if(pwd.charAt(i) == this.c[j]){
                        tmpC = (char)(j + kMin);
                        result += tmpC;
                        j = kChar;
                    }
                }
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "DBKCode{" +
                "id|" + id +
                "|c|" + Arrays.toString(c) +
                '}';
    }

    /**
     * Comproba que la cadena pasada no está ya presente en el archivo
     */
    private static boolean verificated(final char[] c){
        int max_equals = 8;
        boolean verificated = true;
        if(isEmpty()){
            return verificated;
        }
        try{
            InputStream f = new FileInputStream(DBKManager.getFicheroCode());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            try{
                String startCode = "";
                char result;
                int i = 0;
                int counter = 0;
                int datos = bFichero.read();
                boolean found = false;
                while (datos != -1 && verificated){
                    result = (char)datos;

                    if(found){
                        if(result != 32 && result != 44){
                            try{
                                if(c[i] == result){
                                    counter++;
                                }
                                i++;
                            }catch (Exception e){
                                System.out.println("Error [Code 298]: el valor del index " + i + " es superior al limite " + kChar);
                            }
                        }
                    }else{
                        startCode += result;
                    }

                    if(startCode.contains("|c|[")){
                        found = true;
                        startCode = "";
                    }
                    if(i >= kChar){
                        i = 0;
                        found = false;
                    }
                    if(counter >= max_equals){
                        verificated = false;
                    }
                    datos = bFichero.read();
                }
                bFichero.close();
                f.close();
            }catch (IOException e){
                System.out.println("Error [Code 321]: no puedo leer el fichero: " + e.getMessage());
            }
        }catch (FileNotFoundException e){
            System.out.println("Error [Code 324]: problema en abrir fichero: " + e.getMessage());
        }
        return verificated;
    }

    /**
     * Guarda la nueva combinación
     */
    private void save(char[] c){
        Code tmpCode = new Code(c);
        try{
            if(isEmpty()){
                PrintStream f = new PrintStream(DBKManager.getFicheroCode());
                //si es vacio
                f.println(tmpCode);
                f.close();
            }else{
                // no es vacio
                InputStream f = new FileInputStream(DBKManager.getFicheroCode());
                BufferedInputStream bFichero = new BufferedInputStream(f);
                PrintStream otherF = new PrintStream(DBKManager.getDir() + "other");
                try{
                    int datos = bFichero.read();
                    while (datos != -1){
                        otherF.print((char)datos);
                        datos = bFichero.read();
                    }
                    otherF.println(tmpCode);

                    otherF.close();
                    bFichero.close();
                    f.close();

                    // Borrar fichero
                    File tmpFileCode = new File(DBKManager.getDir() + "other");
                    File oldFileCode = new File(DBKManager.getFicheroCode());
                    if(!oldFileCode.delete()){
                        System.out.println("Error [Code 361]: no se ha podido borrar el viejo archivo.");
                    }
                    if(!tmpFileCode.renameTo(oldFileCode)){
                        System.out.println("Error [Code 364]: no se ha podido renombrar el nuevo archivo.");
                    }

                }catch (IOException e) {
                    System.out.println("Error [Code 368]: en lectura del fichero :" + e.getMessage());
                }
            }
        }catch (IOException e) {
            System.out.println("Error [Code 372]: en lectura del fichero :" + e.getMessage());
        }
    }
}
