package program;

public class DBKGameData {
    private int id;
    private int win;
    private int played;

    public DBKGameData() {
    }

    public DBKGameData(int id) {
        this.id = id;
    }

    public DBKGameData(int id, int win, int played) {
        this.id = id;
        this.win = win;
        this.played = played;
    }

    public DBKGameData(String id, String win, String played) {
        try{
            this.id = Integer.parseInt(id);
            this.win = Integer.parseInt(win);
            this.played = Integer.parseInt(played);
        }catch (Exception e){
            System.out.println("Error [GameData 27]: parametros por DBKUser no correctos. id[" + id + "] - win[" + win + "] - played[" + played + "].");
        }
    }

    public int getId() {
        return id;
    }

    public int getWin() {
        return win;
    }

    public int getPlayed() {
        return played;
    }

    public void addWin(){
        this.win += 1;
    }

    public void addPlayed(){
        this.played += 1;
    }

    @Override
    public String toString() {
        return "DBKGameData{" +
                "id|" + id +
                "{dbk_win|" + win +
                "{dbk_played|" + played +
                '}';
    }
}