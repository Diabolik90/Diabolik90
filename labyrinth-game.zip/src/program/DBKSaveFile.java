package program;

import interfaz.DBK;
import java.io.*;
import java.util.HashMap;

public class DBKSaveFile implements DBK {

    @Override
    public int start() {
        if(null == DBKManager.dbkGamer ||
                null == DBKManager.dbkUser){
            System.out.println("Error [SaveFile 12]: al guardar.");
            return 0;
        }

        HashMap<DBKUser, DBKGameData> allUser = new HashMap<>();
        allUser = chargeData(DBKManager.dbkUser.getId());

        if(save(allUser)){
            System.out.println("Guardado con éxito.");
        }else{
            System.out.println("Error [SaveFile 22]: en el guardar los datos.");
        }
        DBKManager.dbkUser = null;
        DBKManager.dbkGamer = null;
        // show profile
        return 0;
    }

    private static HashMap<DBKUser, DBKGameData> chargeData(final int id){
        HashMap<DBKUser, DBKGameData> allUser = new HashMap<>();
        String[] allData = new String[7];
        boolean saved = false;
        try{
            InputStream f = new FileInputStream(DBKManager.getFichero());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            try{
                String[] keys = new String[]{
                        "DBKUserid", "dbk_code", "dbk_username", "dbk_password",
                        "DBKGameDataid", "dbk_win", "dbk_played" };
                String result = "";
                int i = 0;
                int datos = bFichero.read();
                boolean found = false;
                boolean descarte = false;
                while (datos != -1){
                    // descarto las letras y overflow
                    if( i >= keys.length ){
                        i = 0;
                    }
                    if((char)datos < 123){
                        result += (char)datos;
                    }
                    if(found){
                        if((char)datos >= 123){
                            if(i == 0){
                                try{
                                    int tmpId = Integer.parseInt(result);
                                    if( tmpId == id){
                                        allUser.put(DBKManager.dbkUser, DBKManager.dbkGamer);
                                        descarte = true;
                                    }
                                }catch (Exception e){
                                    System.out.println("Error [SaveFile - 64]: en convertir [" + result + "] en entero.");
                                }
                            }
                            allData[i] = result;
                            i++;
                            result = "";
                            found = false;
                            if(i == keys.length){
                                DBKUser otherUser = new DBKUser(allData[2], allData[3], allData[0], allData[1]);
                                DBKGameData otherGame = new DBKGameData(allData[4], allData[5], allData[6]);
                                allUser.put(otherUser,otherGame);
                                descarte = true;
                            }
                        }
                    }
                    if(i < (keys.length)){
                        if(result.contains(keys[i])){
                            found = true;
                            result = "";
                            datos = bFichero.read();
                        }
                    }
                    // clear
                    if(descarte){
                        i=0;
                        result = "";
                        found = false;
                        // espero el salto de linea o la coma
                        if((char)datos == 13 || (char)datos == 44){
                            descarte = false;
                        }
                    }
                    datos = bFichero.read();
                }
                bFichero.close();
                f.close();
            }catch (IOException e){
                System.out.println("Error [SaveFile 101]: no puedo leer el fichero: " + e.getMessage());
            }
        }catch (FileNotFoundException e){
            System.out.println("Error [SaveFile 104]: problema en abrir fichero: " + e.getMessage());
        }
        return allUser;
    }

    private static boolean save(HashMap<DBKUser, DBKGameData> allUser){
        if(null == allUser){
            System.out.println("Error [SaveFile 111]: en guardar los datos. Parametro allUser vacío.");
            return false;
        }
        boolean saved = false;
        try{
            // Creare nuevo fichero y guardar todo
            PrintStream f = new PrintStream(DBKManager.getDir() + "nuevo");
            for(HashMap.Entry i : allUser.entrySet()){
                f.println(i);
            }
            f.close();

            File tmpFile = new File(DBKManager.getDir() + "nuevo");
            File oldFile = new File(DBKManager.getFichero());
            if(!oldFile.delete()){
                System.out.println("Error [SaveFile 126]: no se ha podido borrar el viejo archivo.");
            }
            if(!tmpFile.renameTo(oldFile)){
                System.out.println("Error [SaveFile 129]: no se ha podido renombrar el nuevo archivo.");
            }else{
                saved = true;
            }

        }catch (FileNotFoundException e){
            System.out.println("Error [SaveFile 135]: con el fichero: " + e.getMessage());
        }
        return saved;
    }
}
