package program;

import java.util.Random;

public class DBKUser {

    private String username;
    private String password;
    private int id;
    private int code;

    public DBKUser(){

    }

    public DBKUser(String username, String password) {
        this.username = username;
        this.password = password;
        // asigna el último id
        if(DBKManager.isEmpty()){
            this.id = 0;
        }else{
            this.id = DBKManager.lastId();
        }
        // ID Aleatorio para generar la codificación
        Random rand = new Random();
        this.code = rand.nextInt(DBKManager.getMax_code());
    }

    public DBKUser(String username, String password, int id, int code) {
        this.username = username;
        this.password = password;
        this.id = id;
        this.code = code;
    }

    public DBKUser(String username, String password, String id, String code) {
        this.username = username;
        this.password = password;
        try{
            this.id = Integer.parseInt(id);
            this.code = Integer.parseInt(code);
        }catch (Exception e){
            System.out.println("Error [User 44]: parametros por DBKUser no correctos. id[" + id + "] - code[" + code + "].");
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public int getCode(){ return code; }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "DBKUser{" +
                "id|" + id +
                "{dbk_code|" + code +
                "{dbk_username|" + username +
                "{dbk_password|" + password +
                '}';
    }
}
