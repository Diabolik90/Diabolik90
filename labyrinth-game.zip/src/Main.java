import interfaz.DBK;
import program.*;
import universalCode.Code;
import universalCode.myScanner;

public class Main {

    public static void main(String[] args) {
        // first check for files
        fileControl();
        // loop of the program
        update();

        System.out.println("¡Adios!");
    }



    private static void fileControl(){
        boolean codeEmpty = Code.isEmpty();
        if(codeEmpty){
            if(!DBKManager.isEmpty()){
                System.out.println("Error [Principal 15]: ha sido borrado un fichero importante. El programma borrará el fichero user.");
                DBKManager.deleteUsers();
            }
            Code code = new Code();
            for(int i = 0 ; i < DBKManager.getMax_code(); i++){
                code.create();
            }
        }
    }

    private static void update(){
        DBK myP;
        String result = "";
        myScanner.startScanner();
        do{
            myScanner.hr();
            showIntro();
            result = myScanner.next();
            if(result.equalsIgnoreCase("X")){
                int chose = 0;
                do{
                    if(chose == 0){
                        showMenu();
                        chose = myScanner.getScanner(3);
                    }
                    myP = getDBK(chose);
                    if(null != myP){
                        myScanner.clear();
                        chose = myP.start();
                        myScanner.hr();
                    }
                }while(chose != 3);
                myScanner.clear();
                result = "";
            }
        }while(!result.equalsIgnoreCase("M"));
        myScanner.closeScanner();
    }

    private static void showIntro(){
        final int width = 70;
        myScanner.centerText("¡Bienvenido en el Primer Programa Java de Diabolik!\n", width);
        myScanner.centerText("He desarrollado un programa que requiere, para su acceso, de la introducción", width);
        myScanner.centerText("de credenciales (nombre de usuario y contraseña) o de la realización de un registro.\n", width);
        myScanner.centerText("Las contraseñas han sido codificadas con un programa que crea", width);
        myScanner.centerText("diferentes tipos de codificación y gestionadas con un id.\n", width);
        myScanner.centerText("Una vez realizado el acceso, el programa muestra en la pantalla", width);
        myScanner.centerText("las partidas jugadas y las partidas ganadas por el usuario/a.\n", width);
        myScanner.centerText("El juego es bastante simple, el personaje está representado por una \"O\"", width);
        myScanner.centerText("y tiene que atravesar un laberinto que se crea, en cada nivel/pantalla? de forma aleatoria.\n", width);
        myScanner.centerText("El símbolo \"*\" representa la pared, mientras que \" \" es el espacio vacío", width);
        myScanner.centerText("donde el personaje puede pasar hasta llegar a la cima.\n",width);
        myScanner.centerText("Una vez terminado, los datos se actualizarán y el programa se cerrará.\n", width);
        myScanner.centerText("[PULSAR X PARA CONTINUAR]", width);
        myScanner.centerText("[PULSAR M PARA SALIR]", width);
    }

    static void showMenu(){
        myScanner.clear();
        if(null == DBKManager.dbkUser){
            System.out.println("[1] - Log in");
        }else{
            System.out.println("[1] - Game");
        }
        System.out.println("[2] - Sign in");
        System.out.println("[3] - Exit");
        System.out.println("\nSi no quieres registrarte, puedes acceder con user=[admin] y password=[admin]");
        myScanner.hr();
    }

    static DBK getDBK(final int c){
        switch (c){
            case 1:
                return new DBKLogin();
            case 2:
                return new DBKRegister();
            case 3:
                break;
            case 4:
                return new DBKProfile();
            case 5:
                return new DBKGame();
            case 6:
                return new DBKSaveFile();
            default:
                System.out.println("Error [Principal 103]: párametro [" + c + "] no disponible");
                break;
        }
        return null;
    }

}
