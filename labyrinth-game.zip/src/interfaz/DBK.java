package interfaz;

public interface DBK {
    int start();
}
