package com.company;

/**
 * Crear un pryecto Java
 * Imprimir todos los tipos de variables
 */

public class Variables {

    public static void main(String[] args) {

        byte primero = 1;   // 1 byte
        short segundo = 2;  // 2 byte
        int tercero = 3;    // 4 byte
        float cuarto = 4.1f;    // 4 byte
        long quinto = 5L;    // 8 byte
        double sexto = 6.2d;    // 8 byte

        boolean verdadero = true;
        char character = 'a';
        String nombre = "Diabolik";
        Integer number = null;
        Long longNum = 2L;

        System.out.println("byte: " + primero);
        System.out.println("short: " + segundo);
        System.out.println("int: " + tercero);
        System.out.println("float: " + cuarto);
        System.out.println("long: " + quinto);
        System.out.println("double: " + sexto);
        System.out.println("boolean: " + verdadero);
        System.out.println("char: " + character);
        System.out.println("String: " + nombre);
        System.out.println("Integer: " + number);
        System.out.println("Long: " + longNum);

    }
}
