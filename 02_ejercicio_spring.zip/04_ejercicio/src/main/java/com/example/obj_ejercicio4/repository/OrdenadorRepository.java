package com.example.obj_ejercicio4.repository;

import com.example.obj_ejercicio4.entities.Ordenador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrdenadorRepository extends JpaRepository<Ordenador,Long> {
}
