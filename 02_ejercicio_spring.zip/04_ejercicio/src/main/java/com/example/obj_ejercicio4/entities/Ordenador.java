package com.example.obj_ejercicio4.entities;

import javax.persistence.*;

@Entity
@Table(name = "Ordenadores")
public class Ordenador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String operatingSystem;
    private String type;
    private String processor;
    private Boolean bluetooth;

    public Ordenador() { }

    public Ordenador(String operatingSystem, String type, String processor, Boolean bluetooth) {
        this.operatingSystem = operatingSystem;
        this.type = type;
        this.processor = processor;
        this.bluetooth = bluetooth;
    }

    public Long getId() {
        return id;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public Boolean getBluetooth() {
        return bluetooth;
    }

    public void setBluetooth(Boolean bluetooth) {
        this.bluetooth = bluetooth;
    }
}
