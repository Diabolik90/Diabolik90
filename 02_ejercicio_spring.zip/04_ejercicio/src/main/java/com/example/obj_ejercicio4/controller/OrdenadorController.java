package com.example.obj_ejercicio4.controller;

import com.example.obj_ejercicio4.entities.Ordenador;
import com.example.obj_ejercicio4.repository.OrdenadorRepository;
import org.aspectj.weaver.ast.Or;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class OrdenadorController {

    private OrdenadorRepository repository;

    public OrdenadorController(OrdenadorRepository repository) {
        this.repository = repository;
    }

    /**
     * http://localhost:8087/api/ordenadores
     * @return
     */
    @GetMapping("/api/ordenadores")
    public List<Ordenador> findAll(){
        return repository.findAll();
    }

    /**
     * Añadido desde PostMan
     * Add Request ->
     *      Name: /api/ordenadores
     *      Post: http://localhost:8087/api/ordenadores
     *          Body -> raw -> JSON :
     *          {
     *              "operatingSystem": "Windows 10",
     *              "type": "portatil",
     *              "processor": "Intel i5",
     *              "bluetooth": true
     *          }
     */
    @PostMapping("/api/ordenadores")
    public Ordenador create(@RequestBody Ordenador ordenador){
        return repository.save(ordenador);
    }

}
