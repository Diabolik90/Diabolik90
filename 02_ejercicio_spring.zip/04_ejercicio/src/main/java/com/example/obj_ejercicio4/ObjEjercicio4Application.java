package com.example.obj_ejercicio4;

import com.example.obj_ejercicio4.entities.Ordenador;
import com.example.obj_ejercicio4.repository.OrdenadorRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ObjEjercicio4Application {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(ObjEjercicio4Application.class, args);

		OrdenadorRepository repository = context.getBean(OrdenadorRepository.class);

		Ordenador primero = new Ordenador("Windows 10", "sobremesa", "Intel 5", false);
		Ordenador segundo = new Ordenador("macOS", "portatil", "Core i7", true);
		Ordenador tercero = new Ordenador("Windows 10 Home", "sobremesa", "AMD Ryzen 3 3250U", false);

		repository.save(primero);
		repository.save(segundo);
		repository.save(tercero);

	}

}
