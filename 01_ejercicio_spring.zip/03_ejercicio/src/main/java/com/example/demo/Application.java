package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(Application.class, args);

		UserRepository repository = context.getBean(UserRepository.class);

		System.out.println("El numero de usuarios en BBDD = " + repository.count());

		// crear y almacenar un usuario en BBDD
		User lorenzo = new User(null, "Lorenzo", "Insigne");
		User federico = new User(null, "Federico", "Chiesa");

		repository.save(lorenzo);
		repository.save(federico);

		System.out.println("found");
		System.out.println("El numero de usuarios en BBDD = " + repository.count());

		// recuperar usuarios por id
		System.out.println("Busco todos:\n" + repository.findAll());
	}

}
