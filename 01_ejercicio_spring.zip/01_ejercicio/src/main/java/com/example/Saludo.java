package com.example;

public class Saludo {

    public void imprimirSaludo(){
        System.out.println("Saludos Open BootCamp!");
    }

}
