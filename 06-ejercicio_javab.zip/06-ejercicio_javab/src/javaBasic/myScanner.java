package javaBasic;

import java.util.Scanner;

public class myScanner {

    private static Scanner input;
    private static boolean open = false;

    public static void startScanner(){
        input = new Scanner(System.in);
        open = true;
    }

    public static void closeScanner(){
        if(open)
            input.close();
    }

    public static int getScanner(final int max) {
        int result = 0;
        while(result < 1 | result > max){
            myScanner.startScanner();
            System.out.print("Elige una operación: ");
            try{
                result = input.nextInt();
            }catch (Exception e){
                System.out.println("Ingresaste un valor incorrecto.");
            }
        }
        return result;
    }

    public static String next(){
        return input.next();
    }

    public static String nextLine(){
        return input.nextLine();
    }
}
