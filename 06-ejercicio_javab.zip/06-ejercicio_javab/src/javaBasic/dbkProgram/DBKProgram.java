package javaBasic.dbkProgram;

public interface DBKProgram {

    int start();

}
