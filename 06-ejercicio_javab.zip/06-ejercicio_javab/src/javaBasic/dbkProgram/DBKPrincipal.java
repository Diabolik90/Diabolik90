package javaBasic.dbkProgram;

import javaBasic.DBK;
import javaBasic.Main;
import javaBasic.myScanner;

public class DBKPrincipal implements DBK {
    @Override
    public void function() {
        String result = "";
        boolean codeEmpty = DBKCode.isEmpty();

        if(codeEmpty){
            if(!DBKManager.isEmpty()){
                System.out.println("Error [Principal 15]: ha sido borrado un fichero importante. El programma borrará el fichero user.");
                DBKManager.deleteUsers();
            }
            DBKCode code = new DBKCode();
            for(int i = 0 ; i < DBKManager.getMax_code(); i++){
                code.create();
            }
        }

        DBKProgram myP;
        do{
            Main.hr();
            showIntro();
            result = myScanner.next();
            if(result.equalsIgnoreCase("X")){
                int chose = 0;
                do{
                    if(chose == 0){
                        showMenu();
                        chose = myScanner.getScanner(3);
                    }
                    myP = getProgram(chose);
                    if(null != myP){
                        Main.clear();
                        chose = myP.start();
                        Main.hr();
                    }
                }while(chose != 3);
                Main.clear();
                result = "";
            }
        }while(!result.equalsIgnoreCase("M"));

    }

    public static void centerText(String myString, int limit){
        int size = (limit - myString.length()) / 2;
        for(int i = 0; i < size; i++){
            System.out.print(" ");
        }
        System.out.println(myString);
    }

    private void showIntro(){
        final int width = 70;
        centerText("¡Bienvenido en el Primer Programa Java de Diabolik!\n", width);
        centerText("He desarrollado un programa que requiere, para su acceso, de la introducción", width);
        centerText("de credenciales (nombre de usuario y contraseña) o de la realización de un registro.\n", width);
        centerText("Las contraseñas han sido codificadas con un programa que crea", width);
        centerText("diferentes tipos de codificación y gestionadas con un id.\n", width);
        centerText("Una vez realizado el acceso, el programa muestra en la pantalla", width);
        centerText("las partidas jugadas y las partidas ganadas por el usuario/a.\n", width);
        centerText("El juego es bastante simple, el personaje está representado por una \"O\"", width);
        centerText("y tiene que atravesar un laberinto que se crea, en cada nivel/pantalla? de forma aleatoria.\n", width);
        centerText("El símbolo \"*\" representa la pared, mientras que \" \" es el espacio vacío", width);
        centerText("donde el personaje puede pasar hasta llegar a la cima.\n",width);
        centerText("Una vez terminado, los datos se actualizarán y el programa se cerrará.\n", width);
        centerText("[PULSAR X PARA CONTINUAR]", width);
        centerText("[PULSAR M PARA SALIR]", width);
    }

    static void showMenu(){
        Main.clear();
        if(null == DBKManager.dbkUser){
            System.out.println("[1] - Log in");
        }else{
            System.out.println("[1] - Game");
        }
        System.out.println("[2] - Sign in");
        System.out.println("[3] - Exit");
        System.out.println("\nSi no quieres registrarte, puedes acceder con user=[admin] y password=[admin]");
        Main.hr();
    }

    static DBKProgram getProgram(final int c){
        switch (c){
            case 1:
                return new DBKLogin();
            case 2:
                return new DBKRegister();
            case 3:
                break;
            case 4:
                return new DBKProfile();
            case 5:
                return new DBKGame();
            case 6:
                return new DBKSaveFile();
            default:
                System.out.println("Error [Principal 103]: parametro [" + c + "] no disponible");
                break;
        }
        return null;
    }
}
