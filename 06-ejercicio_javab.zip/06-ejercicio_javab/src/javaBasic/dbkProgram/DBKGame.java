package javaBasic.dbkProgram;

import javaBasic.Main;
import javaBasic.myScanner;
import java.util.Random;

public class DBKGame implements DBKProgram {
    static final int width = 70;
    static final int height = 25;
    static int blast =  5;
    static char[][] labyr = new char[width][height];
    static int[]pos = new int[2];
    static boolean win = false;

    @Override
    public int start() {
        pos[0] = width / 2;
        pos[1] = height;
        /**
         * Creo el laberinto
         */
        createLabyrinth();
        String result = "";
        /**
         * Instrucciones
         */
        while(!result.equalsIgnoreCase("X")){
            show();
            result = myScanner.next();
        }
        result = "";
        /**
         * Bucle de juego
         */
        while(!result.equalsIgnoreCase("M")){
            showGame();
            result = myScanner.next();
            movePlayer(result.charAt(0));
        }
        /**
         * Actualizo el DBKGameData
         */
        DBKManager.dbkGamer.addPlayed();
        if(win)
            DBKManager.dbkGamer.addWin();
        /**
         * DBKSaveFile
         */
        return 6;
    }

    static void show(){
        for(int i = 0; i < height; i++){
            if(i < 5 || i > 20){
                for(int j = 0; j < width; j++){
                    System.out.print(labyr[j][i]);
                }
                System.out.println();
            }else {
                showInstuctions();
                i += 15;
            }
        }
        System.out.println();
        DBKPrincipal.centerText("[ Pulsar X para continuar]", width);
    }

    static void showInstuctions(){
        System.out.println();
        DBKPrincipal.centerText("¡The Knight in the Maze!\n", width);
        DBKPrincipal.centerText("El Jinete Negro tiene que atravesar el bosque", width);
        DBKPrincipal.centerText("para volver a su castillo.", width);
        DBKPrincipal.centerText("Como un buen caballero, no sabe retroceder.", width);
        DBKPrincipal.centerText("Trate de llegar hasta el final", width);
        DBKPrincipal.centerText("y recuerde que puede utilizar hasta 5 ráfagas.", width);
        System.out.println();
        DBKPrincipal.centerText("(A) - Izquierda", width);
        DBKPrincipal.centerText("(D) - Derecha", width);
        DBKPrincipal.centerText("(W) - Arriba", width);
        DBKPrincipal.centerText("(Q) - Explosión", width);
        DBKPrincipal.centerText("(M) - Salir", width);
        System.out.println();
    }

    static void createLabyrinth(){
        Random rand = new Random();
        int valor;
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                valor = rand.nextInt(2);
                if(valor == 0){
                    labyr[j][i] = '*';
                }
                else{
                    labyr[j][i] = ' ';
                }
            }
        }
    }

    static void showGame(){
        Main.clear();
        if(pos[1] > 0){
            showLabyrinth();
        }else{
            if(!win)
                win = true;
            showFinal();
        }
    }

    static void showLabyrinth(){
        Main.clear();
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                System.out.print(labyr[j][i]);
            }
            System.out.println();
        }
        if(!playerInside()){
            for(int i = 0; i < pos[0]; i++){
                System.out.printf(" ");
            }
            System.out.println("O");
        }
        System.out.printf(" Q = Blast [%d]\n", blast);
        System.out.println(" (A) Left - (D) Right - (W) Up - (M) Exit");
    }

    static void showFinal(){
        Main.clear();
        for(int i = 0; i < height; i++){
            if(i < 7 || i > 18){
                for(int j = 0; j < width; j++){
                    System.out.print(labyr[j][i]);
                }
                System.out.println();
            }else {
                showGameOver();
                i += 11;
            }
        }
        System.out.println();
    }

    static void showGameOver(){
        System.out.println("\n");
        DBKPrincipal.centerText("¡The Knight in the Maze!", width);
        System.out.println("\n");
        DBKPrincipal.centerText("Game Over", width);
        System.out.println("\n");
        DBKPrincipal.centerText("[ Pulsar M para salir ]", width);
        System.out.println("\n");
    }

    static void movePlayer(final char c){
        char result = c;
        if(result > 90){
            // solo mayusculas
            result -= 32;
        }
        switch (result){
            case 65: // A
                if(pos[0] > 0 ){
                    toLeft();
                }
                break;
            case 68: // D
                if(pos[0] < (width - 1)){
                    toRight();
                }
                break;
            case 87: // W
                if(pos[1] > 0){
                    toUp();
                }
                break;
            case 81: // Q
                if(blast > 0){
                    blast();
                }
                break;
            case 77: // M
                System.out.println("¡Adios!");
                break;
        }
    }

    static void toLeft(){
        if(!playerInside()){
            pos[0] -= 1;
        }else{
            if(labyr[pos[0] - 1][pos[1]] == 32){
                labyr[pos[0] - 1][pos[1]] = 'O';
                labyr[pos[0]][pos[1]] = ' ';
                pos[0] -= 1;
            }
        }
    }

    static void toRight(){
        if(!playerInside()){
            pos[0] += 1;
        }else{
            if(labyr[pos[0] + 1][pos[1]] == 32){
                try{
                    labyr[pos[0] + 1][pos[1]] = 'O';
                    labyr[pos[0]][pos[1]] = ' ';
                    pos[0] += 1;
                }catch (Exception e){
                    System.out.println("Error [Game 211]: la posición " + pos[0] + " excede el límite " + height);
                }
            }
        }
    }

    static void toUp(){
        if(labyr[pos[0]][pos[1] - 1] == 32){
            try{
                labyr[pos[0]][pos[1] - 1] = 'O';
                if(playerInside()){
                    labyr[pos[0]][pos[1]] = ' ';
                }
                pos[1] -= 1;
            }catch (Exception e){
                System.out.println("Error [Game 226]: la posición " + pos[1] + " excede el límite " + height);
            }
        }
    }

    static void blast(){
        boolean notUp = pos[1] > 0;
        // Up
        if(notUp){
            labyr[pos[0]][pos[1] - 1] = ' ';
            // Left
            if(pos[0] > 1){
                labyr[pos[0] - 1][pos[1] - 1] = ' ';
            }
            // Right
            if(pos[0] < (width - 1)){
                labyr[pos[0] + 1][pos[1] - 1] = ' ';
            }
        }
        // Left
        if(pos[0] > 1 && playerInside()){
            labyr[pos[0] - 1][pos[1]] = ' ';
        }
        // Right
        if(pos[0] < (width - 1) && playerInside()){
            labyr[pos[0] + 1][pos[1]] = ' ';
        }
        blast--;
    }

    static boolean playerInside(){
        return pos[0] < width && pos[1] < height;
    }

}
