package javaBasic.dbkProgram;

import java.io.*;

public class DBKManager {

    public static DBKUser dbkUser = null;
    public static DBKGameData dbkGamer = null;
    private static String fichero = "datos/users";
    private static String ficheroCode = "datos/code";
    private static String dir = "datos/";
    private static final int max_code = 10;

    public static boolean controlChar(String c){
        for(int i = 0; i < c.length(); i++){
            if(32 > c.charAt(i) || c.charAt(i) > 122 || 44 == c.charAt(i)){
                System.out.println("Error [Manager 19]: carácter invalido: " + c.charAt(i));
                return false;
            }
        }
        return true;
    }

    public static boolean isEmpty(){
        int counter = 0;
        boolean empty = true;
        try{
            InputStream f = new FileInputStream(fichero);
            BufferedInputStream bFichero = new BufferedInputStream(f);
            int datos = bFichero.read();
            while (datos != -1 && counter == 0){
                counter++;
                datos = bFichero.read();
            }
            bFichero.close();
            f.close();
        }catch (IOException e){
            empty = true;
        }
        if(counter > 0)
            empty = false;
        return empty;
    }

    public static void deleteUsers(){
        if(isEmpty()){
            return;
        }
        File oldFile = new File(fichero);
        if(oldFile.exists()){
            if(!oldFile.delete()){
                System.out.println("Error [Manager 54]: no se ha podido borrar el viejo archivo.");
            }
        }else{
            System.out.println("Error [Manager 57]: en el borrar el fichero users.");
        }
    }

    public static int lastId(){
        if(isEmpty()){
            return 0;
        }
        String id = "";
        int result = 0;
        boolean copy = false;
        try{
            InputStream f = new FileInputStream(fichero);
            BufferedInputStream bFichero = new BufferedInputStream(f);
            int datos = bFichero.read();
            while (datos != -1){
                if(copy){
                    // solo numeros
                    if(48 <= (char)datos && 57 >= (char)datos){
                        id += (char)datos;
                    }else{
                        try{
                            int tmpId = Integer.parseInt(id);
                            if(tmpId > result){
                                result = tmpId;
                            }
                        }catch (Exception e){
                            System.out.println("Error [Manager 84]: id=[" + id + "] no es un numero.");
                        }
                        id = "";
                        copy = false;
                    }
                }else{
                    // busco |
                    if(124 != (char)datos){
                        id += (char)datos;
                    }else if(id.contains("DBKUser{id")){
                        copy = true;
                        id = "";
                    }
                }
                datos = bFichero.read();
            }
            bFichero.close();
            f.close();
        }catch (IOException e){
            System.out.println("Error [Manager 103]: al leer el último id.");
        }
        result += 1;
        return result;
    }

    public static String getFichero() {
        return fichero;
    }

    public static String getFicheroCode() {
        return ficheroCode;
    }

    public static String getDir() {
        return dir;
    }

    public static final int getMax_code(){
        return max_code;
    }
}
