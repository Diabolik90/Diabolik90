package javaBasic.dbkProgram;

import javaBasic.myScanner;
import java.io.*;

public class DBKLogin implements DBKProgram {
    @Override
    public int start() {
        boolean empty = DBKManager.isEmpty();
        /**
         * Si no hay usuarios vuelve al menu
         */
        if(empty){
            System.out.println("Error [Login 14]: no hay usuarios registrados.");
            return 0;
        }
        /**
         * Si está registrado un usuario va directamente al juego
         */
        int result = 4;
        /**
         * Pide las llaves para el login y guarda los datos
         * en DBKManager.dbkUser y DBKManager.dbkGamer
         */
        if(null == DBKManager.dbkUser){
            result = RequestData();
        }
        /**
         * DBKProfile or Main
         */
        return result;
    }

    static int RequestData(){
        int result = 0;
        DBKUser access = null;
        String myUsername = "";
        String myPassword = "";
        boolean confirmed = false;
        for(int i = 0; i < 3; i++){
            do{
                myScanner.startScanner();
                System.out.println("Escribir tu nombre de usuario: ");
                myUsername = myScanner.nextLine();
                confirmed = DBKManager.controlChar(myUsername);
            }while (!confirmed);
            confirmed = false;
            do{
                System.out.println("Escribir tu contraseña: ");
                myPassword = myScanner.nextLine();
                confirmed = DBKManager.controlChar(myPassword);
            }while (!confirmed);
            access = controlLogin(myUsername, myPassword);
            if(null != access){
                DBKManager.dbkUser = access;
                /**
                 * DBKProfile
                 */
                result = 4;
                i = 3;
            }else{
                System.out.println("Ingreso al sistema incorrecto. Te quedan "+ (2-i) + " intentos");
            }
        }
        return result;
    }

    static DBKUser controlLogin(String user, String pwd){
        String[] tmpDatos = new String[]{ "", "", user, pwd };
        boolean controlOk = false;
        try{
            InputStream f = new FileInputStream(DBKManager.getFichero());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            try{
                String[] keys = new String[]{
                        "DBKUserid", "dbk_code", "dbk_username", "dbk_password" };
                String result = "";
                int i = 0;
                int datos = bFichero.read();
                boolean found = false;
                boolean descarte = false;
                while (datos != -1 && !controlOk){
                    // descarto las letras overflow
                    if( i >= keys.length ){
                        i = 0;
                    }
                    if((char)datos < 123){
                        result += (char)datos;
                    }
                    if(found){
                        if((char)datos >= 123){
                            tmpDatos[i] = result;
                            if( i == 2){
                                if(!tmpDatos[i].equals(user)){
                                    descarte = true;
                                }
                            }
                            // username control
                            if(i == 3){
                                try{
                                    int tmpID = Integer.parseInt(tmpDatos[0]);
                                    DBKCode myCode = new DBKCode();
                                    myCode.read(tmpID);
                                    tmpDatos[i] = myCode.codification(pwd);
                                    if(tmpDatos[i].equals(result)){
                                        controlOk = true;
                                    }
                                }catch (Exception e){
                                    System.out.println("Error [Login 111]: en convertir [" + tmpDatos[0] + "] en entero.");
                                }
                            }
                            i++;
                            result = "";
                            found = false;
                        }
                    }
                    if(i < (keys.length)){
                        if(result.contains(keys[i])){
                            found = true;
                            result = "";
                            datos = bFichero.read();
                        }
                    }
                    // clear
                    if(descarte){
                        i=0;
                        result = "";
                        found = false;
                        descarte = false;
                    }
                    datos = bFichero.read();
                }
                bFichero.close();
                f.close();
            }catch (IOException e){
                System.out.println("Error [Login 138]: no puedo leer el fichero: " + e.getMessage());
            }
        }catch (FileNotFoundException e){
            System.out.println("Error [Login 141]: problema en abrir fichero: " + e.getMessage());
        }
        if(controlOk){
            return new DBKUser(user, tmpDatos[3], tmpDatos[0], tmpDatos[1]);
        }
        return null;
    }

}
