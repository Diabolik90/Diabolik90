package javaBasic.dbkProgram;

import javaBasic.myScanner;
import java.io.*;
import java.util.HashMap;

public class DBKRegister implements DBKProgram {

    @Override
    public int start() {
        boolean empty = DBKManager.isEmpty();
        HashMap<DBKUser, DBKGameData> myUser = new HashMap<>();

        myUser = insertData(empty);

        saveNewUser(myUser, empty);

        /**
         * Main
         */
        return 1;
    }

    /**
     * Control que el nombre usuario sea disponible
     */
    static boolean controlUser(String user){
        boolean controlOk = true;
        try{
            InputStream f = new FileInputStream(DBKManager.getFichero());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            try{
                String result = "";
                int datos = bFichero.read();
                boolean start = false;
                while (datos != -1 && controlOk){
                    if(start && 123 != (char)datos){
                        if(126 != (char)datos){
                            result += (char)datos;
                        }else{
                            if(result.equalsIgnoreCase(user)){
                                System.out.println("Error [Register 42]: el nombre elegido no está disponible: " + user);
                                controlOk = false;
                            }
                            result = "";
                            start = false;
                        }
                    }
                    if(123 == (char)datos)
                        start = true;

                    datos = bFichero.read();
                }
                bFichero.close();
                f.close();
            }catch (IOException e){
                System.out.println("Error [Register 57]: no puedo leer el fichero: " + e.getMessage());
            }
        }catch (FileNotFoundException e){
            System.out.println("Error [Register 60]: problema en abrir fichero: " + e.getMessage());
        }
        return controlOk;
    }

    /**
     * Pido al usuario de insertar sus datos
     */
    static HashMap<DBKUser, DBKGameData> insertData(boolean empty){
        String myUsername = "";
        String myPassword = "";
        boolean confirmed = false;
        do{
            myScanner.startScanner();
            System.out.println("Elige un nombre de usuario: ");
            myUsername = myScanner.nextLine();
            confirmed = DBKManager.controlChar(myUsername);
            if(confirmed && !empty){
                confirmed = controlUser(myUsername);
            }
        }while (!confirmed);
        confirmed = false;
        do{
            System.out.println("Escribir una contraseña: ");
            myPassword = myScanner.nextLine();
            confirmed = DBKManager.controlChar(myPassword);
        }while (!confirmed);
        DBKCode code = new DBKCode(DBKManager.lastId());
        String tmpPwd = code.codification(myPassword);
        DBKManager.dbkUser = new DBKUser(myUsername, tmpPwd);
        DBKManager.dbkGamer = new DBKGameData(DBKManager.dbkUser.getId());
        HashMap<DBKUser, DBKGameData> result = new HashMap<>();
        result.put(DBKManager.dbkUser, DBKManager.dbkGamer);
        return result;
    }

    /**
     * Guardo los datos usuario en el archivo
     */
    private void saveNewUser(HashMap<DBKUser, DBKGameData> user, boolean empty){
        try{
            if(empty){
                PrintStream f = new PrintStream(DBKManager.getFichero());
                //si es vacio
                f.println(user);
                f.close();
            }else{
                //si no es vacio
                InputStream f = new FileInputStream(DBKManager.getFichero());
                BufferedInputStream bFichero = new BufferedInputStream(f);
                PrintStream otherF = new PrintStream(DBKManager.getDir() + "nuevo");
                try{
                    int datos = bFichero.read();
                    while (datos != -1){
                        otherF.print((char)datos);
                        datos = bFichero.read();
                    }
                    otherF.println(user);

                    otherF.close();
                    bFichero.close();
                    f.close();

                    // Borrar fichero
                    File tmpFile = new File(DBKManager.getDir() + "nuevo");
                    File oldFile = new File(DBKManager.getFichero());
                    if(!oldFile.delete()){
                        System.out.println("Error [Register 127]: no se ha podido borrar el viejo archivo.");
                    }
                    if(!tmpFile.renameTo(oldFile)){
                        System.out.println("Error [Register 130]: no se ha podido renombrar el nuevo archivo.");
                    }

                } catch (IOException e) {
                    System.out.println("Error [Register 134]: en lectura del fichero :" + e.getMessage());
                }

            }

        }catch (FileNotFoundException e){
            System.out.println("Error [Register 140]: con el fichero: " + e.getMessage());
        }
    }
}
