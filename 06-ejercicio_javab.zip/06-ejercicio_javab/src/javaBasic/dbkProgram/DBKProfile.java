package javaBasic.dbkProgram;

import javaBasic.Main;
import javaBasic.myScanner;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class DBKProfile implements DBKProgram{
    @Override
    public int start() {
        int id = DBKManager.dbkUser.getId();
        if(null == DBKManager.dbkGamer){
            DBKGameData tmpGame = getGameData(id);
            if(null == tmpGame){
                DBKManager.dbkUser = null;
                System.out.println("Error [Profile 18]: al cargar archivos de juego.");
                /**
                 * Main
                 */
                return 0;
            }
            DBKManager.dbkGamer = tmpGame;
        }
        int chose = 0;
        boolean game = false;
        do{
            showMenu();
            chose = myScanner.getScanner(2);
            if(1 == chose){
                game = true;
                chose = 2;
            }
        }while (chose != 2);

        /**
         * DBKGame
         */
        if(game)
            return 5;

        /**
         * DBKSaveFile
         */
        return 6;
    }

    private static void showMenu(){
        System.out.println(" Bienvenido " + DBKManager.dbkUser.getUsername());
        System.out.println("Hasta ahora tienes:");
        System.out.println("[" + DBKManager.dbkGamer.getPlayed() + "] partidos jugados");
        System.out.println("[" + DBKManager.dbkGamer.getWin() + "] partidos ganados");
        Main.hr();
        System.out.println("\n Puedes:");
        System.out.println("[1] - Jugar");
        System.out.println("[2] - Salir");
        Main.hr();
    }

    private DBKGameData getGameData(final int id){
        int[] tmpDatos = new int[]{ id, 0 , 0 };
        boolean controlOk = false;
        try{
            InputStream f = new FileInputStream(DBKManager.getFichero());
            BufferedInputStream bFichero = new BufferedInputStream(f);
            try{
                String[] keys = new String[]{
                        "DBKGameDataid", "dbk_win", "dbk_played" };
                String result = "";
                int i = 0;
                int datos = bFichero.read();
                boolean found = false;
                boolean descarte = false;
                while (datos != -1 && !controlOk){
                    // descarto las letras y overflow
                    if( i >= keys.length ){
                        i = 0;
                    }
                    if((char)datos < 123){
                        result += (char)datos;
                    }
                    if(found){
                        if((char)datos >= 123){
                            if(i == 0){
                                try{
                                    int tmpId = Integer.parseInt(result);
                                    if( tmpId != id){
                                        descarte = true;
                                    }
                                }catch (Exception e){
                                    System.out.println("Error [Profile 92]: en convertir [" + result + "] en entero.");
                                }
                            }else{
                                try{
                                    int tmpInt = Integer.parseInt(result);
                                    tmpDatos[i] = tmpInt;
                                }catch (Exception e){
                                    System.out.println("Error [Profile 99]: en convertir [" + result + "] en entero.");
                                }
                            }
                            i++;
                            result = "";
                            found = false;
                            if(i == keys.length){
                                controlOk = true;
                            }
                        }
                    }
                    if(i < (keys.length)){
                        if(result.contains(keys[i])){
                            found = true;
                            result = "";
                            datos = bFichero.read();
                        }
                    }
                    // clear
                    if(descarte){
                        i=0;
                        result = "";
                        found = false;
                        descarte = false;
                    }
                    datos = bFichero.read();
                }

                bFichero.close();
                f.close();
            }catch (IOException e){
                System.out.println("Error [Profile 130]: no puedo leer el fichero: " + e.getMessage());
            }
        }catch (Exception e){
            System.out.println("Error [Profile 133]: problema en abrir fichero: " + e.getMessage());
        }
        if(controlOk){
            return new DBKGameData(tmpDatos[0],tmpDatos[1], tmpDatos[2]);
        }
        return null;
    }
}
