package javaBasic;

public interface DBK {
    void function();
}
