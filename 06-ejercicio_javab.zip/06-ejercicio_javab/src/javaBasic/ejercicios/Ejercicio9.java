package javaBasic.ejercicios;

import javaBasic.DBK;
import java.io.*;

/**
 * Utilizando InputStream y PrintStream,
 * crea una función que reciba dos parámetros: "fileIn" y "fileOut".
 * La tarea de la función será realizar la copia del fichero dado
 * en el parámetro "fileIn" al fichero dado en "fileOut".
 */

public class Ejercicio9 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 9:\nCrea una función que realize la copia del fichero dado \"fileIn\" al fichero dado en \"fileOut\".");

        String ruta = "datos/";
        String fileIn = "file-in";
        String fileOut = "file-out";
        CopyFile((ruta + fileIn), (ruta + fileOut));
        ReadFile(ruta+fileIn);
        ReadFile(ruta+fileOut);
    }

    public static void CopyFile(String fIn, String fOut){
        // Abro el primer fichero
        try {
            InputStream fichero = new FileInputStream(fIn);
            BufferedInputStream bFichero = new BufferedInputStream(fichero);
            //Abro el segundo fichero
            PrintStream myFichero = new PrintStream(fOut);
            // Leo el contenido
            try{
                int datos = bFichero.read();
                while (datos != -1){
                    myFichero.print((char)datos);
                    datos = bFichero.read();
                }
                // cierro los ficheros
                myFichero.close();
                bFichero.close();
                fichero.close();
            } catch (IOException e) {
                System.out.println("Error [Ejercicio9 45]: en lectura del fichero " + fIn + ": " + e.getMessage());
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error [Ejercicio9 48]: fichero " + fIn + " no encontrado: " + e.getMessage());
        }
    }

    public static void ReadFile(String f){
        try{
            InputStream fichero = new FileInputStream(f);
            BufferedInputStream bFichero = new BufferedInputStream(fichero);
            try{
                // Leo el contenido
                System.out.println("Contenido del fichero " + f + ": ");
                int datos = bFichero.read();
                while (datos != -1){
                    System.out.print((char)datos);
                    datos = bFichero.read();
                }
                bFichero.close();
                fichero.close();
            }catch (IOException e){
                System.out.println("Error [Ejercicio9 67]: en lectura del fichero " + f + ": " + e.getMessage());
            }

        }catch (FileNotFoundException e){
            System.out.println("Error [Ejercicio9 71]: fichero " + f + " no encontrado: " + e.getMessage());
        }
    }
}
