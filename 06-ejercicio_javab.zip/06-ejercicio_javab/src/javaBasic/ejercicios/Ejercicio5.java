package javaBasic.ejercicios;

import javaBasic.DBK;
import java.util.Vector;

/**
 * Indica cuál es el problema de utilizar un Vector con la capacidad por defecto
 * si tuviésemos 1000 elementos para ser añadidos al mismo.
 */

public class Ejercicio5 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 5:\nIndica cuál es el problema de utilizar un Vector con la capacidad por defecto.");

        Vector<Integer> myVec = new Vector<Integer>();
        final int elements = 1000;

        for(int i = 0; i < elements; i++){
            myVec.add(i);
        }
        System.out.println("El Vector contiene " + myVec.size() + " elementos pero hemos ocupado " + myVec.capacity() + " espacio en memoria.");

        Vector<Integer> otherVec = new Vector<Integer>(20,10);

        for(int i = 0; i < elements; i++){
            otherVec.add(i);
        }
        System.out.println("Inicializando con la capacidad de incremento, evitamos dicho error:");
        System.out.println("El nuevo Vector contiene " + otherVec.size() + " y " + otherVec.capacity() + " espacio en memoria.");
    }
}
