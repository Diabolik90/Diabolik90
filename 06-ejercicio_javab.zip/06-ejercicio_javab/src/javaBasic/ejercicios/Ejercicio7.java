package javaBasic.ejercicios;

import javaBasic.DBK;
import java.util.ArrayList;
import java.util.List;

/**
 * Crea un ArrayList de tipo int, y, utilizando un bucle rellénalo con elementos 1..10.
 * A continuación, con otro bucle, recórrelo y elimina los numeros pares.
 * Por último, vuelve a recorrerlo y muestra el ArrayList final.
 * Si te atreves, puedes hacerlo en menos pasos, siempre y cuando cumplas el primer "for" de relleno.
 */

public class Ejercicio7 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 7:\nCrea un ArrayList de tipo int y rellénalo con elementos 1..10. Elimina los numeros pares.");
        List<Integer> myList = new ArrayList<>();
        int limit = 10;

        System.out.print("Lista completa: [ ");
        for(int i = 1; i <= limit; i++){
            myList.add(i);
            System.out.print(myList.get(i-1) + " ");
        }
        System.out.println("]");

        System.out.print("Lista impares:  [ ");
        for(int i = 0; i < limit; i++){
            if(myList.get(i)%2 != 0){
                System.out.print(myList.get(i) + " ");
            }else{
                myList.remove(i);
                limit--;
                i--;
            }
        }
        System.out.println("]");
    }
}
