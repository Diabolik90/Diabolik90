package javaBasic.ejercicios;

import javaBasic.DBK;

/**
 * Crea una función DividePorCero.
 * Esta, debe generar una excepción ("throws") a su llamante del tipo ArithmeticException
 * que será capturada por su llamante (desde "main", por ejemplo).
 * Si se dispara la excepción, mostraremos el mensaje "Esto no puede hacerse".
 * Finalmente, mostraremos en cualquier caso: "Demo de código".
 */

public class Ejercicio8 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 8:\nCrea una función DividePorCero. Si se dispara la excepción, mostraremos el mensaje \"Esto no puede hacerse\".");

        try{
            DividePorCero(4, 0);
        }catch (ArithmeticException ignored){ }
    }

    public static void DividePorCero(int a, int b) throws ArithmeticException{
        System.out.println("Operación solicitada: " + a + " / " + b );
        int result = 0;
        try{
            result = a / b;
            System.out.println("El resultado de " + a + " / " + b + " es = " + result);
        }catch (Exception e){
            System.out.println("Esto no puede hacerse: [" + e.getMessage() + "]");
            throw new ArithmeticException();
        }finally {
            System.out.println("Demo de código.");
        }
    }
}
