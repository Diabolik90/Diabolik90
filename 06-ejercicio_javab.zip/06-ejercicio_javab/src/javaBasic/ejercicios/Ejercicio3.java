package javaBasic.ejercicios;

import javaBasic.DBK;
import java.util.Random;

/**
 * Crea un array bidimensional de enteros y recórrelo,
 * mostrando la posición y el valor de cada elemento en ambas dimensiones.
 */

public class Ejercicio3 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 3:\nCrea un array bidimensional de enteros y recórrelo, mostrando la posición y el valor de cada elemento.");

        final int first = 5;
        final int second = 12;

        // Genero números aleatorio desde 0 hasta 99
        final int maxim_valor = 100;
        Random rand = new Random();

        // Paso el valor
        int[][] myArray = new int[first][second];
        for(int i = 0; i < first; i++){
            for(int j = 0; j < second; j++){
                myArray[i][j] = rand.nextInt(maxim_valor);
            }
        }

        for(int i = 0; i < first; i++){
            for(int j = 0; j < second; j++){
                System.out.printf("Valor de myArray[%2d][%2d] = [%d]\n",i,j,myArray[i][j]);
                myArray[i][j] = rand.nextInt(maxim_valor);
            }
            if( i != (first - 1))
                System.out.println();
        }
    }
}
