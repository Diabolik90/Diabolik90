package javaBasic.ejercicios;

import javaBasic.DBK;

/**
 * Crea un array unidimensional de Strings y recórrelo,
 * mostrando únicamente sus valores.
 */

public class Ejercicio2 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 2:\nCrea un array unidimensional de Strings y recórrelo.");

        String[] myString = new String[]{
                "Java Básico",
                "Java Avanzado",
                "Testing con JUnit",
                "HTML y CSS",
                "JavaScript Básico",
                "Spring",
                "Hibernate",
                "Jenkins y Sonarqube",
                "ReactJS",
                "ReactJS Avanzado"
        };

        System.out.print("{ ");
        int length = myString.length -1;
        for(String i : myString){
            System.out.print(i);
            if(!i.equals(myString[length]))
                System.out.print(", ");
        }
        System.out.println(" }");
    }
}
