package javaBasic.ejercicios;

import javaBasic.DBK;

import java.util.Vector;

/**
 * Crea un "Vector" del tipo de dato que prefieras, y añádele 5 elementos.
 * Elimina el 2o y 3er elemento y muestra el resultado final.
 */

public class Ejercicio4 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 4:\nCrea un Vector y añádele 5 elementos. Elimina el 2o y 3er elemento y muestra el resultado final.");

        Vector<Integer> myVec = new Vector<Integer>();
        final int elements = 5;

        for(int i = 0; i < elements; i++){
            myVec.add(i * 2);
            System.out.print("[" + i * 2 + "] ");
        }
        System.out.println();

        myVec.remove(1);
        myVec.remove(1);

        for(int i : myVec){
            System.out.print("[" + i + "] ");
        }
        System.out.println();
    }
}
