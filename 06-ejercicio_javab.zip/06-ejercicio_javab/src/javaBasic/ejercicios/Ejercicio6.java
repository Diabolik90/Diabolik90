package javaBasic.ejercicios;

import javaBasic.DBK;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Crea un ArrayList de tipo String, con 4 elementos.
 * Cópialo en una LinkedList. Recorre ambos mostrando únicamente el valor de cada elemento.
 */

public class Ejercicio6 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 6:\nCrea un ArrayList de tipo String, con 4 elementos. Cópialo en una LinkedList. Recorre ambos mostrando únicamente el valor de cada elemento.");
        List<String> myList = new ArrayList<>();
        myList.add("Primero");
        myList.add("Segundo");
        myList.add("Tercero");
        myList.add("Cuarto");
        LinkedList<String> myLinkedList = new LinkedList<>(myList);
        System.out.print("Contenido de ArrayList: \n[ ");
        for(String list : myList){
            System.out.print(list + " ");
        }
        System.out.println("]");
        System.out.print("Contenido de LinkedList: \n[ ");
        for(String list : myLinkedList){
            System.out.print(list + " ");
        }
        System.out.println("]");
    }
}
