package javaBasic.ejercicios;

import javaBasic.DBK;

/**
 * Escribe el código que devuelva una cadena al revés.
 * Por ejemplo, la cadena "hola mundo", debe retornar "odnum aloh".
 */

public class Ejercicio1 implements DBK {
    @Override
    public void function() {
        System.out.println("Ejercicio 1:\nEscribe el código que devuelva una cadena al revés.");

        String myString = new String("Open Bootcamp");
        String revers = "";
        for(int i = (myString.length() - 1); i >= 0; i--){
            revers += myString.charAt(i);
        }
        System.out.println("Original: [" + myString + "]");
        System.out.println("Revers:   [" + revers + "]");
    }
}
