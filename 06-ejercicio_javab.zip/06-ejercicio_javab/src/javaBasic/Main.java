package javaBasic;

import javaBasic.dbkProgram.DBKPrincipal;
import javaBasic.ejercicios.*;

public class Main {

    public static void main(String[] args) {
        DBK myEjercicio;
        myScanner.startScanner();
        final int max_exercise = 11;
        int chose;
        do{
            clear();
            showMenu(max_exercise);
            chose = myScanner.getScanner(max_exercise);
            myEjercicio = getExercise(chose);
            if(null != myEjercicio){
                clear();
                myEjercicio.function();
                hr();
            }
        }while(chose != max_exercise);

        myScanner.closeScanner();
    }

    public static void hr(){
        System.out.println("-----------------------------");
    }

    public static void clear(){
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n");
        hr();
    }

    static void showMenu(int max){
        hr();
        System.out.println("Ejercicios modulo 10 de Diabolik: ");
        System.out.println("[1] - Escribe el código que devuelva una cadena al revés.");
        System.out.println("[2] - Crea un array unidimensional de Strings y recórrelo.");
        System.out.println("[3] - Crea un array bidimensional de enteros y recórrelo, mostrando la posición y el valor de cada elemento.");
        System.out.println("[4] - Crea un Vector y añádele 5 elementos. Elimina el 2o y 3er elemento y muestra el resultado final.");
        System.out.println("[5] - Indica cuál es el problema de utilizar un Vector con la capacidad por defecto.");
        System.out.println("[6] - Crea un ArrayList de tipo String, con 4 elementos. Cópialo en una LinkedList. Recorre ambos mostrando únicamente el valor de cada elemento.");
        System.out.println("[7] - Crea un ArrayList de tipo int y rellénalo con elementos 1..10. Elimina los numeros pares.");
        System.out.println("[8] - Crea una función DividePorCero. Si se dispara la excepción, mostraremos el mensaje \"Esto no puede hacerse\".");
        System.out.println("[9] - Crea una función que realize la copia del fichero dado \"fileIn\" al fichero dado en \"fileOut\".");
        System.out.println("[10] - Sorpréndenos creando un programa de tu elección que utilice InputStream, PrintStream, excepciones, un HashMap y un ArrayList, LinkedList o array.");
        System.out.printf("[%d] - Salir\n", max);
        hr();
    }

    static DBK getExercise(final int c){
        switch (c){
            case 1:
                return new Ejercicio1();
            case 2:
                return new Ejercicio2();
            case 3:
                return new Ejercicio3();
            case 4:
                return new Ejercicio4();
            case 5:
                return new Ejercicio5();
            case 6:
                return new Ejercicio6();
            case 7:
                return new Ejercicio7();
            case 8:
                return new Ejercicio8();
            case 9:
                return new Ejercicio9();
            case 10:
                return new DBKPrincipal();
            case 11:
                System.out.println("\n¡Adios!");
                break;
            default:
                System.out.println("Error en el programa. Selección [" + c + "] no disponible");
                break;
        }
        return null;
    }
}
