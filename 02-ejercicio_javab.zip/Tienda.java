package com.openbootcamp;

import java.util.Scanner;

/**
 * Author: Diabolik
 * Ejercicio 2 Open BootCamp Java Básico
 * Crear una función que reciba un precio y devuelva el precio con IVA incluido
 */

public class Tienda {

    public static final double iva = 0.22d;

    public static void main(String[] args) {
        int chose = 0;
        do{
            showMenu();
            chose = getMenu();
            page(chose);
        }while(chose != 3);
    }

    static void showMenu(){
        System.out.println("Bienvenidos al E-commerce de zapatillas");
        System.out.println("1 - Ver zapatillas");
        System.out.println("2 - Comprar zapatillas");
        System.out.println("3 - Salir");
        System.out.println();
    }

    static int getMenu(){
        int result = 0;
        while(result < 1 | result > 3){
            Scanner input = new Scanner(System.in);
            result = input.nextInt();
        }
        return result;
    }

    static void page(int c){
        switch (c){
            case 1:
                System.out.println("Has elegido de ver las zapatillas");
                break;
            case 2:
                articulos();
                break;
            case 3:
                System.out.println("¡Adios!");
                break;
            default:
                System.out.println("Error en el programa");
                break;
        }
        System.out.println();
    }

    static void articulos(){
        String[] articulos = new String[]{"Articulo 1", "Articulo 2", "Articulo 3", "Articulo 4"};
        double[] precio = new double[]{185.45d, 68.29d, 121.19d, 89.99d};
        System.out.println("Elige un articulo:");
        for(int i = 0; i < articulos.length; i++){
            System.out.print(articulos[i] + " ................ ");
            try{
                System.out.printf("[%.2f €] con IVA: ", precio[i]);
                System.out.printf("%.2f € \n", calculateIva(precio[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static double calculateIva(double valor){
        return iva * valor + valor;
    }

}
