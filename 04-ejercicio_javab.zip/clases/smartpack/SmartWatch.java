package com.openbootcamp.clases.smartpack;

public class SmartWatch extends SmartDevice{

    String fabricante;
    boolean connected;

    public SmartWatch(){
        this.fabricante = "***";
        this.connected = false;
    }

    public SmartWatch(String fabricante, boolean connected) {
        this.fabricante = fabricante;
        this.connected = connected;
    }

    public SmartWatch(boolean internet, String fabricante, boolean connected) {
        super(internet);
        this.fabricante = fabricante;
        this.connected = connected;
    }

    public void call(int number){
        if(!this.connected) {
            this.conecting();
            this.connected = this.internet;
        }
        if(connected)
            System.out.println("Llamando numero " + number);
        else
            System.out.println("Imposible conectar");

    }

    @Override
    public String toString() {
        return "SmartWatch{" +
                "internet=" + internet +
                ", fabricante='" + fabricante + '\'' +
                ", connected=" + connected +
                '}';
    }
}
