package com.openbootcamp.clases.smartpack;

public class SmartDevice {

    boolean internet;

    public SmartDevice(){
        this.internet = false;
    }

    public SmartDevice(boolean internet){
        this.internet = internet;
    }

    public void conecting(){
        if(!internet)
            System.out.println("Efectuando conexión");
        else
            System.out.println("El dispositivo ya está conectado");
    }

}
