package com.openbootcamp.clases.smartpack;

public class SmartPhone extends SmartDevice{
    String fabricante;
    String modelo;
    int numero;
    boolean camara;

    public SmartPhone(){
        this.fabricante = "***";
        this.modelo = "***";
        this.numero = 0;
        this.camara = false;
    }

    public SmartPhone(String fabricante, String modelo, int numero, boolean camara) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.numero = numero;
        this.camara = camara;
    }

    public SmartPhone(boolean internet, String fabricante, String modelo, int numero, boolean camara) {
        super(internet);
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.numero = numero;
        this.camara = camara;
    }

    public void call(int number){
        if(this.numero != 0)
            System.out.println("Llamando el numero " + number);
        else
            System.out.println("El telefono " + this.fabricante + " - " + this.modelo + " no tiene numero.");
    }

    public void foto(){
        if(camara)
            System.out.println("¡Foto!");
        else
            System.out.println("El telefono " + this.fabricante + " - " + this.modelo + " no tiene camara.");
    }

    public void readMail(){
        if(!this.internet)
            this.conecting();
        if(this.internet)
            System.out.println("Leyendo correo");
        else
            System.out.println("Impossible conectar");
    }

    public String getFabricante() {
        return fabricante;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "SmartPhone{" +
                "internet=" + internet +
                ", fabricante='" + fabricante + '\'' +
                ", modelo='" + modelo + '\'' +
                ", numero=" + numero +
                ", camara=" + camara +
                '}';
    }
}
