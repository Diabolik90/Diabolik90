package com.openbootcamp.clases;

import com.openbootcamp.clases.smartpack.SmartPhone;
import com.openbootcamp.clases.smartpack.SmartWatch;

/**
 * Author: Diabolik
 * Ejercicio 4 Open BootCamp Java Básico
 * Crear una clase SmartDevice. Dentro crearéis las clases hijas: SmartPhone y SmartWatch.
 * Agregaréis atributos tal cual tendrían esos objetos en la realidad.
 * Crear constructor vacío y con todos los parámetros para cada clase.
 * Desde una clase Main: crearéis objetos de cada una y los utilizaréis para imprimir sus valores por consola.
 */

public class Main {

    public static void main(String[] args) {

        SmartPhone telefono = new SmartPhone("Samsung","S7",666854689,true);
        SmartPhone telefono1 = new SmartPhone();
        SmartWatch reloj = new SmartWatch(true, "Apple", true);

        System.out.println(reloj.toString());
        telefono1.call(telefono.getNumero());
        telefono1.setNumero(666548985);
        telefono1.call(telefono.getNumero());
        System.out.println("El numero del telefono " + telefono1.getModelo() + " es " + telefono1.getNumero());
    }
}
