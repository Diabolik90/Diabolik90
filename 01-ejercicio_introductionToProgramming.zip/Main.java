/**
 * Para este ejercicio deberás utilizar como lenguaje Java y hacer lo siguiente:
 *
 *
 *     Declarar una variable de tipo int llamada numero1.
 *
 *     Mostrarla por pantalla.
 *
 *     Modificar el valor de la variable numero1.
 *
 *     Mostrarla por pantalla.
 *
 *     Crea un array de 4 elementos.
 *
 *     Mostrar el elemento en la posición 0.
 */

public class Main {

    public static void main(String[] args) {
        int numero1 = 0;
        System.out.println("Variable numero1=" + numero1);

        numero1 = 10;
        System.out.println("Variable numero1=" + numero1);

        int[] array = new int[4];

        for(int i = 0; i < array.length; i++){
            array[i] = i;
        }

        System.out.println("array[0]=" + array[0]);
    }
}
